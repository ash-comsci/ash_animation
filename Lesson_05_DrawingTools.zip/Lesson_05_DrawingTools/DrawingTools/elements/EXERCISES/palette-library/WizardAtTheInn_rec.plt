ToonBoomAnimationInc PaletteFile 2
Solid    "General Line"             0x0a189da3b690a356   0   0   0 255
Solid    "Hair Inside Line Dark"    0x0a18f4c1f47699c1 107 208 191 255
Solid    "Hair Inside Line Light"   0x0a18f4c1f4769aa8 186 255 248 255
Solid    "Eyewhite Line & Fill"     0x0a18f4c1f4769cb5 255 255 255 255
Solid    "Pupil Line & Fill"        0x0a18f4c1f4769d93  63  59  80 255
Solid    "Brooch Rim Line & Fill"   0x0a18f4c1f476a70a 169 169   2 255
Solid    "Brooch Gem Line"          0x0a18f4c1f476b9ea  67 174 180 255
Solid    "Brooch Highlight"         0x0a18f4c1f476c3bb 189 247 255 255
Solid    "Robe Seam Line"           0x0a18f4c1f476c761 178 176  38 255
