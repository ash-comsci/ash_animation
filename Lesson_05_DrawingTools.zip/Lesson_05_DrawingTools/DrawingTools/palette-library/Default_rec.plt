ToonBoomAnimationInc PaletteFile 2
Solid    NoColor                    0x0934ca5093dd3e8f 255   0   0 255
