ToonBoomAnimationInc PaletteFile 2
Solid    SHADOW                     0x0a13b8dccd90a524 200 202 205 255
Solid    Instructions_line          0x072ef7648a0324af   0   0   0 255
Solid    White                      0x0a14aeb1c261aad8 255 255 255 255
Solid    character_sketch           0x0936c686b2eb09f2  16  49 120 255
Solid    Cat                        0x072ef812169c3a19 200 210 213 255
Solid    "Cat Eye"                  0x072ef812169c69fe 237 236 218 255
Solid    Cat_shade                  0x0934cf29f32cbd9f 200 210 213 255
Solid    CatTongue                  0x072ef812169c7311 167  98  98 255
Solid    Cat_spots                  0x0934cf29f32cc035 165 188 203 255
Solid    Bowl                       0x0934cf29f32f51c0 197  80  80 255
Solid    Bowl_int                   0x0934cf29f32fd81e 122  36  36 255
Solid    Line_water                 0x093538a2df009434  62 162 207 255
Solid    Fill_water                 0x093538a2df0094e3 151 211 237 255
Gradient WatermelonPeel             0x072ef7648a0324b5 Radial 
{        0.0 243 255 199 255,
        34.2 206 251  85 255,
       100.0  85 213 101 255 }
Gradient Watermelon                 0x072ef7648a0324b3 Radial 
{       57.9 233  68 115 255,
        89.5 255 147 172 255,
       100.0 237 196 212 255 }
Gradient WatermelonSeeds            0x072ef7648a0324b7 Radial 
{        0.0 177 148 122 255,
        34.2  56  43  31 255 }
Solid    Watermelon_Mouth           0x0a14aeb1c2666be8 153  21  65 255
Solid    Watermelon_Eyes            0x0a14aeb1c26554cd  30  25  20 255
Solid    Shark_black                0x0934ca5093df8254  40  38  38 255
Solid    Shark_Eye_Teeth            0x0934ca5093df829a 224 224 224 255
Solid    Shark_Skin_01              0x0934ca5093df82e1 129 143 146 255
Solid    Shark_Skin_02              0x0934ca5093df8329 183 197 200 255
Solid    Shark_Nostrils             0x0934ca5093dfa989  49  66  72 255
Solid    Shark_Collar               0x0934cf29f3213ade 138  67  63 255
Solid    Shark_Shirt                0x0934cf29f3213ae0 165 100  94 255
Solid    Shark_Skin_Tone            0x0934cf29f3215031 105 116 118 255
Solid    Shark_Eye_Tone             0x0934cf29f322d944 161 161 161 255
Solid    Shark_Black_Tone           0x0934cf29f322d946   0   0   0 255
Solid    Shark_Collar_Tone          0x0936c686b2ebf05c 104  50  47 255
Solid    Shark_Shirt_Tone           0x0934cf29f322d948 124  74  71 255
Solid    Shark_Skin_01_Hilight      0x0a14f267c455daf2 170 188 191 255
Solid    Shark_Skin_02_Hilight      0x0a14f267c455db74 211 226 229 255
Solid    Shark_Black_Hilight        0x0a14f267c455dbf7  98  94  94 255
Solid    Shark_Collar_Hilight       0x0a14f267c455dc7b 187  90  85 255
Solid    Shark_Shirt_Hilight        0x0a14f267c455dd00 197 117 113 255
Solid    Shark_Eye_Hilight          0x0a14f267c4579e6d 245 245 245 255
Solid    Dog_fill                   0x0936c686b2ead9e8  92  83  83 255
Gradient Sky_Gradient               0x072efc393683c022 Linear 
{        0.0 199 198 102 255,
        43.5 223 241 253 255,
       100.0  91 183 245 255 }
Solid    Bird_line                  0x09373362c2b4e1f3  36  58  11 255
Gradient Bird_Fill                  0x09373362c2b4e244 Radial 
{       15.8 239 100  45 255,
        38.6 209 225  35 255,
        67.5 209 225  35 255,
        91.2 110 165  33 255,
       100.0  94 153  27 255 }
Gradient Bird_Eyes                  0x09373362c2b623f0 Radial 
{        0.0 227 227 227 255,
        27.2   0   0   0 255 }
Solid    Bird_Beak_Feet             0x09373362c2b695ce 239 184 171 255
Texture  Bird_Wall                  0x0a1627b369861a63 Tile
Solid    Bird_Wall_Shadow           0x09373362c2b78059  90  84  82 255
Solid    Croc_skin                  0x09374ade60f16554  57  96  54 255
Solid    Croc_skin_line             0x09374ade60f165c0  21  56  14 255
Solid    Croc_skin2                 0x09374ade60f16613 223 218 133 255
Solid    Croc_skin2_line            0x09374ade60f16667 153 136  43 255
Solid    Croc_shorts_line           0x09374ade60f16c16  90  27  12 255
Solid    Croc_shorts_ribbon         0x0938f428ca54a2b2 109  54  40 255
Solid    Croc_shorts                0x09374ade60f16c6c 147  55  33 255
Solid    Croc_eye_teeth             0x09374ade60f16cc3 255 255 255 255
Solid    Croc_plates                0x09374ade60f16d1b 104  81  56 255
Solid    Croc_plates_line           0x09374ade60f16d74  68  49  28 255
Solid    Croc_teeth_line            0x0938f428ca56164e  95 105 106 255
Solid    Sloth_Shirt                0x0938f428ca5ec638 215 215 215 255
Solid    Sloth_Cardigan             0x0938f428ca5ec695  64 107 131 255
Solid    Sloth_Shape1               0x0938f428ca5ec6f3 255 185  46 255
Solid    Sloth_Shape2               0x0938f428ca5ec752 153  51  34 255
Solid    Sloth_Shape3               0x0938f428ca5ec7b2 191 103  39 255
Solid    Sloth_Pants                0x0938f428ca5ec813  54  48  44 255
Solid    Sloth_Skin                 0x0938f428ca5ec875 143 122 107 255
Solid    Sloth_Nose                 0x0938f428ca5ec8d8  56  52  50 255
Solid    Sloth_Eyes_Shoetip         0x0938f428ca5ecc78 255 255 255 255
Solid    Sloth_Blush                0x0938f428ca5eccdd 163  97  97 255
Solid    Sloth_Shoes                0x0938f428ca5ecd43 201 147  41 255
Solid    Sloth_Eyes_Spots           0x0938fd2275e1ff21  84  64  54 255
Solid    Sloth_fingers              0x0938fd2275e2f1bc 179 171 137 255
Solid    Tucan_body                 0x0939354aa556ff00  70  67  67 255
Solid    Tucan_eye                  0x0939354aa556ff78 227 227 227 255
Solid    Tucan_pupil                0x0939354aa556ffd7  48  48  48 255
Solid    Tucan_eye_spot2_tail_wing  0x0939354aa5570098  46  95 129 255
Solid    Tucan_beek1-5              0x0939354aa55700fa  34  33  33 255
Solid    Tucan_beek_eyespot         0x0939354aa5570651 237 213  76 255
Solid    Tucan_beek3_eyespot        0x0939354aa55706b5 237 114  76 255
Solid    Tucan_beek4_heart          0x0939354aa5585145 199  51  17 255
Solid    Tucan_branch               0x0939354aa5570780  94  57   9 255
Solid    Tucan_leaves               0x0939354aa55709db  28 149  27 255
Solid    Stamp_Grass_1              0x0a162ed3ce892fce  88 151  55 255
Solid    Stamp_Grass_2              0x0a162ed3ce893089 122 191  85 255
Solid    Stamp_Grass_3              0x0a162ed3ce893111 155 231 105 255
Gradient Stamp_Sky                  0x0a162ed3ce89319a Linear 
{        0.0 106 232 241 255,
       100.0 195 225 225 255 }
Solid    Stamp_Flower_1             0x0a162ed3ce8b7ec7 203 184  78 255
Solid    Stamp_Flower_2             0x0a162ed3ce8b7f5a 136 209 211 255
Solid    Stamp_Flower_3             0x0a162ed3ce8b7fee 104  96 219 255
Solid    Stamp_Flower_4             0x0a162ed3ce8b8083  53  48 126 255
Solid    Stamp_Flower_5             0x0a162ed3ce8b8119 149  49  72 255
Solid    Stamp_Flower_6             0x0a162ed3ce8b81b0 255 145 244 255
Solid    Stamp_Flower_7             0x0a162ed3ce8b8248 231 237  80 255
Solid    FRAME1                     0x0a13b8dccd906191 233 242 253 255
Solid    FRAME2                     0x0a13b8dccd90bc3e 247 247 247 255
