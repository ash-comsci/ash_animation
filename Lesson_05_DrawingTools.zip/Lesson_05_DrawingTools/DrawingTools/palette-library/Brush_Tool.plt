ToonBoomAnimationInc PaletteFile 2
Solid    sketch_clean               0x09a6e2eb51756401   0   0   0 255
Solid    sketch_blue                0x09a6e2eb51756def   0   0 207 125
Solid    sketch_red                 0x09a6e2eb51756e14   0   0   0 255
Solid    sketch_green               0x09a6e2eb51756e39   0   0   0 255
