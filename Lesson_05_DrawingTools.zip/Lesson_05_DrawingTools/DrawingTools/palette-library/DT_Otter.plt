ToonBoomAnimationInc PaletteFile 2
Solid    OTT_Line                   0x0ad5c4a7c451c071   0   0   0 255
Solid    OTT_Main                   0x0ad5c4a7c451c409 179 132 170 255
Solid    OTT_Belly                  0x0ad5c4a7c451c42f 223 195 218 255
Solid    OTT_Eyes                   0x0ad5c4a7c451c456 237 144  88 255
Solid    OTT_Eye_White_Teeth        0x0ad5c4a7c451c47e 255 255 255 255
Solid    OTT_Stencil_Line           0x0ad5c4a7c4551c32  58  22 165 255
Solid    OTT_Stencil_Shade          0x0ad5c4a7c4577491 106  58 129  87
